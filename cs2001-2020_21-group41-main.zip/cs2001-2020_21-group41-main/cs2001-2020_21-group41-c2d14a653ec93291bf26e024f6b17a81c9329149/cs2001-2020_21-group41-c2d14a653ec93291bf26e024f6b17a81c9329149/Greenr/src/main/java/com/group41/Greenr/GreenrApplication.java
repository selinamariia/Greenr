package com.group41.Greenr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenrApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenrApplication.class, args);
	}

}
