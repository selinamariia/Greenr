package com.group41.Greenr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenrApplicationTests {

	@Test
	void contextLoads() {
	}

}
