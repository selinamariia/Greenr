# cs2001-2020_21-group41
cs2001-2020_21-group41 created by GitHub Classroom

# Project Name:
Greenr

# Project Description:
Our project aims to tackle UN sustainable development goals 3: Good Health and Well-Being, 11: Sustainable Cities and Development, and 13: Climate Action. We aim to do this in 3 main ways:

1) Give the general public easy access to data on pollution levels.
2) Raise awareness about the different kinds of pollution and the harmful effects they have on peoples’ health.
3) Encourage people to take an active role in caring for their community.

# Contributors:
Aaron Patterson

Avneesh Thakar

Bishwasta Magar

Selina Bucur

Joshua Fields

Rebecka Evans

Mark Mouawad
